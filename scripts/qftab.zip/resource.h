//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ftabfirst.rc
//
#define IDD_DIALOG_SETUP                101
#define IDC_IPREGD                      1001
#define IDC_IPRFTN                      1002
#define IDC_IGROWO                      1003
#define IDC_ISKIPO                      1004
#define IDC_ICRWK1                      1005
#define IDC_LADYFILE                    1006
#define IDC_FTABBONE                    1007
#define IDC_IGRWYR                      1009
#define IDC_ISKIPY                      1010
#define IDC_IFSTYR                      1011
#define IDC_ILSTYR                      1012
#define IDC_FYRPRC                      1013
#define IDC_CUMCAPADD                   1014
#define IDC_CUMOILGAS                   1015
#define Comment                         1016
#define IDC_COMENT                      1017
#define IDC_MAXCOL                      1018
#define IDC_ICOLWD                      1019
#define IDC_multi                       1020
#define IDC_S_NPV                       1021
#define IDC_CHECKrun2                   1022
#define IDC_UT_DR                       1023
#define IDC_CARBON_OR_2                 1024
#define IDC_TABREQ                      1025
#define IDC_CHECKrun3                   1026
#define IDC_CHECKrun4                   1027
#define IDC_CHECKrun5                   1028
#define IDC_CHECKrun6                   1029
#define IDC_CHECKrun7                   1030
#define IDC_COMBO_RUN2                  1031
#define IDC_Radio_UserRuns              1032
#define IDC_Radio_BrowseRuns            1033
#define IDC_RADIO_Allruns               1034
#define IDC_EDIT_USER                   1038
#define IDC_CHECK_MultiRan              1040
#define IDC_EDIT_GRAF2000               1041
#define IDC_BUTTON_TabReq               1042
#define IDC_COMBO_RUN1                  1043
#define IDC_COMBO_RUN4                  1044
#define IDC_COMBO_RUN5                  1045
#define IDC_COMBO_RUN6                  1046
#define IDC_COMBO_RUN7                  1047
#define IDC_COMBO_RUN3                  1048
#define IDC_BUTTON_Browse_TabReq        1049
#define IDC_EDIT_PWD                    1050
#define IDC_EDIT_FTABEXE                1051
#define IDC_EDIT_FTABEXE2               1052
#define IDC_EDIT_Launch                 1052

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1052
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
