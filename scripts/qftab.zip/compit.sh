ifort /check:nobounds /compile_only /libs:qwins /nologo /traceback /warn:argument_checking /warn:nofileopt  qftab.f90
#link qftab.obj kernel32.lib debug/ftabfirst.res /nologo /subsystem:windows /incremental:no /machine:I386 /nodefaultlib:"dfconsol.lib" /out:"qftab.exe"
link qftab.obj kernel32.lib debug/ftabfirst.res /nologo /subsystem:windows /incremental:no  /nodefaultlib:"dfconsol.lib" /out:"qftab.exe"
  
