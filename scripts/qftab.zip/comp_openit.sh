f90 /libs:qwins /compile_only openit.f90
link /subsystem:windows openit.obj
