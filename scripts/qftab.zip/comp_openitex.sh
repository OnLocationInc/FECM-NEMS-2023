f90 /libs:qwins /compile_only openit_ex.f90
link /subsystem:windows openit_ex.obj
