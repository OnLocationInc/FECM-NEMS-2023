#$Header: N:/default/scripts/RCS/tfiler.sh,v 1.5 2005/09/16 13:04:09 DSA Exp $
# TFILER script
# create an input file called tfiler.files that looks something like this:

#   Dictionary /default/input/dict.v1.1
#   Restarti   /default/input/restart.v1.1
#   In Format  1
#   Varlist    /default/input/varlist.v1.1
#   Restarto   /u/dsa/trash/tfiler/d0207957/@.restart
#   Out Format 0
#   Filer Obj  /default/objects/filer.v1.1.obj
# make sure they're not in the directory for this script when they execute it.
 if [ $PWD = "$NEMS/scripts" ]
   then
   echo "     Sorry.  There is a slight problem."
   echo "     Your current directory is  $PWD."
   echo "     Please execute this from another directory."
   exit 1
 fi
 if [ -f tfiler.files ] ; then 
   grep "Exec" tfiler.files >/dev/null
   if [ $? = "1" ] ; then
     read rem?"The tfiler setup file, tfiler.files, exists.  Remove (y/n)? [n] : "
     if [ -n "$rem" ] ; then
       case $rem in
       y|Y|yes|YES) rm tfiler.files ;;
       esac 
     fi 
   else
      rm tfiler.files
   fi 
 fi
 if [ ! -f tfiler.files ] ; then
# use the NEMS fdef script to determine the default version of each input file

   sh -K $NEMS/scripts/fdef.sh dict.txt s    > temp1.$$
   sed "s/.*is //g" temp1.$$ > temp2.$$
   read vers < temp2.$$
   dict="$NEMS/input/dict.v$vers.txt"
   sh -K $NEMS/scripts/checkfor.z.sh $dict print
   echo "Dictionary $dict" > tfiler.files

   sh -K $NEMS/scripts/fdef.sh restart.unf s > temp1.$$
   sed "s/.*is //g" temp1.$$ > temp2.$$
   read vers < temp2.$$
   restarti="$NEMS/input/restart.v$vers.unf"
   sh -K $NEMS/scripts/checkfor.z.sh $restarti print
   echo "Restarti   $restarti" >>tfiler.files
                          
# determine whether the input restart file is a unformatted or formatted
   file $restarti | awk '{print tolower($0)}' > temp1.$$
   sed "s/.*maybe/1  Unformatted/g;
        s/.*ascii text/0  Formatted/g" temp1.$$ > temp2.$$
   read fmt trans dummy < temp2.$$
   echo "In Format  1  Unformatted" >> tfiler.files
                           
   sh -K $NEMS/scripts/fdef.sh varlist.txt s > temp1.$$
   sed "s/.*is //g" temp1.$$ > temp2.$$
   read vers < temp2.$$
   varlist="$NEMS/input/varlist.v$vers.txt"
   sh -K $NEMS/scripts/checkfor.z.sh $varlist print
   echo "Varlist    $varlist" >>tfiler.files
#                      
   restarto="$PWD/tfiler.out"
   echo "Restarto   $restarto" >> tfiler.files
   echo "Out Format 0  Formatted" >> tfiler.files

   sh -K $NEMS/scripts/fdef.sh filer.obj s > temp1.$$
   sed "s/.*is //g" temp1.$$ > temp2.$$
   read vers < temp2.$$
   tfiler=$NEMS/objects/filer.v$vers.obj
   sh -K $NEMS/scripts/checkfor.z.sh $tfiler print
   echo "Filer Obj  $tfiler" >>tfiler.files
   date=`date`
   echo "$USER $date" >> tfiler.files
   echo "==================================================" >> tfiler.files
   rm temp1.$$
   rm temp2.$$ 
 else
     head -1 tfiler.files > temp3.$$
     read dummy file < temp3.$$
     if [ -n "$file" ] ; then
        sh -K $NEMS/scripts/checkfor.z.sh $file
        if [ $? -eq "0" ] ; then
           dict=$file
        else
           read ans?"$file does not exist.  Hit enter to continue."
        fi
     fi
     newdict="Dictionary $dict" ; 
     sed -e "/Dictionary/ s?.*?$newdict?" tfiler.files > tfiler.temp ;
     mv tfiler.temp tfiler.files ;
     head -2 tfiler.files | tail -1 > temp3.$$
     read dummy file < temp3.$$
     if [ -n "$file" ] ; then
        sh -K $NEMS/scripts/checkfor.z.sh $file
        if [ $? -eq "0" ] ; then
           restarti=$file
           file $restarti | awk '{print tolower($0)}' > temp1.$$
           sed "s/.*maybe/1  Unformatted/g;
                s/.*ascii text/0  Formatted/g" temp1.$$ > temp2.$$

           read fmt trans dummy < temp2.$$
           rm temp1.$$
           rm temp2.$$
        else
           read ans?"$file does not exist.  Hit enter to continue."
        fi
     fi
     newi="Restarti   $restarti" ;
     sed -e "/Restarti/ s?.*?$newi?" tfiler.files > tfiler.temp ;
     mv tfiler.temp tfiler.files  
     sed -e "/In Format/ s?.*?In Format  $fmt  $trans?" tfiler.files > tfiler.temp ;
     mv tfiler.temp tfiler.files ;
     head -4 tfiler.files | tail -1 > temp3.$$
     read dummy file < temp3.$$
     if [ -n "$file" ] ; then
      sh -K $NEMS/scripts/checkfor.z.sh $file
      if [ $? -eq "0" ] ; then
           varlist=$file
        else
           read ans?"$file does not exist.  Hit enter to continue."
        fi
     fi
     newvar="Varlist    $varlist" ;
     sed -e "/Varlist/ s?.*?$newvar?" tfiler.files > tfiler.temp ;
     mv tfiler.temp tfiler.files ;
     head -7 tfiler.files | tail -1 > temp3.$$
     read dummy dum file < temp3.$$
     if [ -n "$file" ] ; then
        sh -K $NEMS/scripts/checkfor.z.sh $file
        if [ $? -eq "0" ] ; then
           tfiler=$file
        else
           read ans?"$file does not exist.  Hit enter to continue."
        fi
     fi
     newvar="Filer Obj  $tfiler" 
     sed -e "/Filer Obj / s?.*?$newvar?" tfiler.files > tfiler.temp 
     mv tfiler.temp tfiler.files ;
     rm temp3.$$
 fi
   askagain="0"
   while [ "$askagain" != "8" ]
     do
     clear  
     echo "  TFILER "
     echo " "
     echo "  The contents of the TFILER Setup File is :"
     echo " "
     cat tfiler.files | sed "s/^/    /g" 
     echo " "
     echo "    TFILER Setup Menu"  
     echo
     echo " 1> Dictionary File" 
     echo " 2> Input Restart File" 
     echo " 3> Varlist File" 
     echo " 4> Output Restart File" 
     echo " 5> Format for Output Restart File" 
     echo " 6> Filer Object "
     echo " ======================================="
     echo " 7> Begin TFILER" 
     echo " 8> Quit" 
     echo " "
     read askagain?"    Enter Selected Option: [1-8] "  
     case $askagain in
       1|D|d) read file?"    Enter Dictionary File : "  
              if [ -n "$file" ] ; then
                 sh -K $NEMS/scripts/checkfor.z.sh $file
                 if [ $? -eq "0" ] ; then
                    dict=$file
                 else
                    read ans?"$file does not exist.  Hit enter to continue."
                 fi
              fi
              newdict="Dictionary $dict" ; 
              sed -e "/Dictionary/ s?.*?$newdict?" tfiler.files > tfiler.temp ;
              mv tfiler.temp tfiler.files ;;
       2|I|i) read file?"    Enter Input Restart File : "
              if [ -n "$file" ] ; then
                sh -K $NEMS/scripts/checkfor.z.sh $file
                if [ $? -eq "0" ] ; then
                    restarti=$file
                    file $restarti | awk '{print tolower($0)}' > temp1.$$
                    sed "s/.*maybe/1  Unformatted/g;
                         s/.*ascii text/0  Formatted/g" temp1.$$ > temp2.$$

                    read fmt trans dummy < temp2.$$
                    rm temp1.$$
                    rm temp2.$$
                 else
                    read ans?"$file does not exist.  Hit enter to continue."
                 fi
              fi
              newi="Restarti   $restarti" ;
              sed -e "/Restarti/ s?.*?$newi?" tfiler.files > tfiler.temp ;
              mv tfiler.temp tfiler.files  
              sed -e "/In Format/ s?.*?In Format  $fmt  $trans?" tfiler.files > tfiler.temp ;
              mv tfiler.temp tfiler.files ;;
       3|V|v) read file?"    Enter Varlist File : "
              if [ -n "$file" ] ; then
                 sh -K $NEMS/scripts/checkfor.z.sh $file
                 if [ $? -eq "0" ] ; then
                    varlist=$file
                 else
                    read ans?"$file does not exist.  Hit enter to continue."
                 fi
              fi
              newvar="Varlist    $varlist" ;
              sed -e "/Varlist/ s?.*?$newvar?" tfiler.files > tfiler.temp ;
              mv tfiler.temp tfiler.files ;;
       4|O|o) echo "Enter Output Restart File" ; read out ;
              newo="Restarto   $out" ;
              sed -e "/Restarto/ s?.*?$newo?" tfiler.files > tfiler.temp ;
              mv tfiler.temp tfiler.files ;;
       5|F|f) echo "     Specify the format for the output restart file:"
              echo "     0  Formatted (text)"
              echo "     1  Unformattted (binary)"
              echo "     2  not available yet"
              echo "     3  PC WK1 format"
              read ans?"     Enter Format (0-3) [0] : "
              if [ -n "$ans" ] ; then
                fmt=$ans
                if [ $fmt = 1 ] ; then
                  newfmt="Out Format $fmt  Unformatted" ;
                else
                  newfmt="Out Format $fmt  " ;
                fi
              else
                fmt="0"
                newfmt="Out Format $fmt  Formatted" ;
              fi
              sed -e "/Out Format/ s?.*?$newfmt?" tfiler.files > tfiler.temp ;
              mv tfiler.temp tfiler.files ;; 
       6|E|e) read file?"    Enter Filer Object File : "
              if [ -n "$file" ] ; then
                sh -K $NEMS/scripts/checkfor.z.sh $file
                if [ $? -eq "0" ] ; then
                    tfiler=$file
                 else
                    read ans?"$file does not exist.  Hit enter to continue."
                 fi
              fi
              newvar="Filer Obj  $tfiler" 
              sed -e "/Filer Obj / s?.*?$newvar?" tfiler.files > tfiler.temp 
              mv tfiler.temp tfiler.files ;;

       7|B|b) cat tfiler.files >> $NEMS/logs/tfiler.log 
# link TFILER 
echo " Linking TFILER object code to create an executable"
# --- Get object file defaults, used to create executable
 sh -K $NEMS/scripts/fdef.sh tfiler.obj s | sed "s/.*is //g" > temp.$$ ; read vers1 < temp.$$ ; rm temp.$$
 vers1="$NEMS/objects/tfiler.v$vers1.obj"
 if [ -f tfiler.obj ] ; then
    vers1="tfiler.obj"
    echo "local tfiler.obj found so it will be used"
 fi
 vers3=$tfiler
 sh -K $NEMS/scripts/fdef.sh fwk1io.obj s | sed "s/.*is //g" > temp.$$ ; read vers4 < temp.$$ ; rm temp.$$
 vers4="$NEMS/objects/fwk1io.v$vers4.obj"
 if [ -f fwk1io.obj ] ; then
   vers4="fwk1io.obj"
   echo "local fwk1io.obj found so it will be used"
 fi
 sh -K $NEMS/scripts/fdef.sh cio4wk1.obj s | sed "s/.*is //g" > temp.$$ ; read vers5 < temp.$$ ; rm temp.$$
 vers5="$NEMS/objects/cio4wk1.v$vers5.obj"
 if [ -f cio4wk1.obj ] ; then
   vers5="cio4wk1.obj"
   echo "local cio4wk1.obj found so it will be used"
 fi
 rm -f tfiler.objs
#
OBJS="\
$vers1 \
$vers3 \
$vers4 \
$vers5 "
 notthere=0
 for item in $OBJS
 do
    echo "$item" | sed 's/\/\//\\\\/;s/\//\\/g' >> tfiler.objs
    sh -K $NEMS/scripts/checkfor.z.sh $item print
    if [ $? -ne "0" ] ; then
      notthere=1
    fi
 done
 if [ $notthere -eq 1 ] ;then
   echo "not continuing because of missing object files"
   exit
 fi
   
#link /out:tfiler.exe @tfiler.objs
. $NEMS/scripts/ifortvars.sh
xilink /out:tfiler.exe @tfiler.objs
echo "Running tfiler: "
              tfiler.exe 
              exit ;;    
       8|Q|q) echo " "
              exit ;; 
       *)     echo "     Option not Available" ; 
              read ans?"     Press <Enter> to Continue" 
              askagain=6 ;;
     esac
 done   
