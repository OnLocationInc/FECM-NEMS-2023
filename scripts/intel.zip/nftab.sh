# $Header: N:/default/scripts/RCS/nftab.sh,v 1.35 2005/10/11 20:47:46 PKC Exp $
trap "exit" 1 2 15
function read_access {
#   function read_access checks to see if:
#     1. file exist
#     2. user has read access to file
#     3. file is not a directory or some other special file type
#  function returns 0 if all test passed and returns -1 on error
#  
# --- does file exist
  sh -K $NEMS/scripts/checkfor.z.sh $1
  if [[ ! -a $1 ]]; then
    print "$0: file $1 not found"
    return -1
  fi
# --- does user have read access
  if [[ ! -r $1 ]]; then   
    print "$0: do not have read permission for $1"
    return -1
  fi  
# --- file is not directory or other special file type
  if [[ ! -f $1 ]]; then   
    print "$0: file $1 is either a directory or other special type"
    return -1
  fi  
  return 0
  }
# Start of script - Print a heading
. $NEMS/scripts/commands.sh
print " "
print " "
print "***************************************"
print "*   NEMS Ftab Report Writer Script    *"
print "***************************************"
print " "
print "Press return to get default answers shown in brackets <>"
print " "
# --- See how many restart files are to be in the report
acceptable=0
default_year=2004
while [[ $acceptable = 0 ]]
do
  print -n 'Number of runs to report (1-7): <1> '
  read NUMSCEN
  case $NUMSCEN in
     [1-7]   ) acceptable=1;;
     *       ) if [[ -z "$NUMSCEN" ]]; then              
                 let NUMSCEN=1
                 acceptable=1
               else
                 print '*** UNACCEPTABLE RESPONSE -- RE-ENTER ***'   
               fi;;
  esac
done           
# --- Get valid names for restart files, uses function read_access
let count=0
while [[ $count < $NUMSCEN ]]
do
  let count=count+1
  found=0
  while [[ $found != 1 ]]
  do
    print -n "Enter restart version (vx.x) or run scenario $count: <aeo2005> "
    read SCEN[$count]
    if [[ -z "${SCEN[$count]}" ]]; then
      SCEN[$count]='aeo2005'
    fi
#  see if the entry is in the form vx.x
    ivers=0
    ivers=`echo "${SCEN[$count]}" | grep -c "v[1-9][0-9]*\.[0-9]*" `
    if [ "$ivers" -gt 0 ] ; then
      RESTART[$count]="$NEMS/input/restart.${SCEN[$count]}" 
      DATEKEY[$count]="${SCEN[$count]}"
      SCEN[$count]="restart"
    else
      acceptable=0
      while [[ $acceptable = 0 ]]
      do
        print -n "Enter run datekey $count:"
        read DATEKEY[$count]
        if [[ -z "${DATEKEY[$count]}" ]]; then
          print '$0: *** DATEKEY HAS NO DEFAULT VALUE - RE-ENTER ***'
          print ' '
        else
          acceptable=1
        fi
      done      
      # --- Get full restart file name using runlog
      grep  "\/${SCEN[$count]}\/${DATEKEY[$count]}" $NEMS/logs/runlog | sed "s!^... !!"  > temp.$$
      read RESTART[$count] < temp.$$ ; rm temp.$$
      print "${RESTART[$count]}" | sed "s!/${SCEN[$count]}!!" | sed "s!/${DATEKEY[$count]}!!" > temp.$$
      read RUNDIR < temp.$$ ; rm temp.$$
      print "${RESTART[$count]}/RESTART.unf" > temp.$$ ; read RESTART[$count] < temp.$$ ; rm temp.$$
      # --- check existence, access, and file type of restart file
    fi
    sh -K $NEMS/scripts/checkfor.z.sh ${RESTART[$count]} 
    if read_access ${RESTART[$count]}; then
      found=1
    else
      print "$0: *** RE-ENTER RUN SCENARIO & DATEKEY AGAIN ***"
      print " "
      print " "
    fi
  done
done  
# --- TABREQ portion of script
# --- Find out which tables to be shown in the report
# lnkinems:  use Intel linker and libraries for intel-compiled versions in aeo2006 and beyond
lnkinems=0  
self=0
acceptable=0
while [[ $acceptable = 0 ]]
do
  print " "
  print "Select from the following types of output reports:"
  print "     1 - AEO tables"
  print "     4 - Other (defined by your input file)"
  print -n "Enter your choice (1, or 4) :<1>"
  read SELECTED

  case $SELECTED in
      1        )  fdef tabreq.txt s default | sed "s/.*is //g" > temp.$$ ; read tbrqvers < temp.$$ ; rm temp.$$
                  TABREQ=$NEMS/input/tabreq.v$tbrqvers.txt
                  acceptable=1 ;;
      4        )  self=1; acceptable=1;;
      *        )  if [[ -z "$SELECTED" ]]; then
                    fdef tabreq.txt s default | sed "s/.*is //g" > temp.$$ ; read tbrqvers < temp.$$; rm temp.$$
                    TABREQ=$NEMS/input/tabreq.v$tbrqvers.txt
                    acceptable=1
                  else
                    print "*** UNACCEPTABLE RESPONSE - RE-ENTER ***"
                  fi;;
  esac
done  
#print " SELECTED = $SELECTED"
#
# --- get a valid name for tabreq file if 4 selected
while [[ "$self" = 1 ]]
do
  print -n 'Enter the name of the tabreq file: '
  read TABREQ
# --- check existence, access, and file type of tabreq file
  sh -K $NEMS/scripts/checkfor.z.sh $TABREQ
  if read_access $TABREQ; then
    self=0
  else
    print "$0: *** RE-ENTER TABREQ FILE AGAIN ***"
    print " "
    print " "
  fi
done
# see if default printing options to be used
acceptable=0
while [[ $acceptable = 0 ]]
do
  print " "
  print -n "Use the default printing options (y/n)? "
  read PRINTDEF
  case $PRINTDEF in
       [Yy]    ) self=0
                 acceptable=1;;
       [Nn]    ) self=1
                 acceptable=1;;         
       *       ) if [[ -z "$PRINTDEF" ]]; then
                   print " *** THIS ITEM HAS NO DEFAULT "
                 fi  
                 print " *** UNACCEPTABLE RESPONSE - RE-ENTER ***";;
  esac     
done
DEFDOLYR="$default_year"
if [[ $self = 1 ]]; then
  # --- if default print settings not selected
  # --- see if wish to print regions
  print " "
  print -n "Do you want to print regions (y/n)? <n>"
  read YAORNA
  case $YAORNA in
     [Yy]    ) REGIONS=1;;
     *       ) REGIONS=0;;         
  esac     
  print " "
  print -n "Do you want to print carbon (as opposed to carbon dioxide) (y/n)? <y>"
  read YAORNA
  case $YAORNA in
     [Nn]    ) FTABCARB="co2";;
     *       ) FTABCARB="c";;         
  esac 
  # --- Get first print year for report
  acceptable=0
  while [[ $acceptable = 0 ]]
  do
    print -n "Enter the first print year: <2002> "
    read FYR
    if [[ -z "$FYR" ]]; then
      FYR=2002; acceptable=1
    else
      if [[ $FYR < 1990 || $FYR > 2050 ]]; then
        print " *** UNACCEPTABLE START YEAR - RE-ENTER *** "
        print " "
      else 
        acceptable=1
      fi
    fi
  done
  # --- Get last print year of report        
  acceptable=0
  while [[ $acceptable = 0 ]]
  do
    print -n "Enter the last print year: <2030> "
    read LYR
    if [[ -z "$LYR" ]]; then
      LYR=2030; acceptable=1
    else
      if [[ $LYR < $FYR || $LYR > 2050 ]]; then
        print " *** UNACCEPTABLE LAST YEAR - RE-ENTER *** "
        print " "
      else 
        acceptable=1
      fi
    fi
  done     
  # --- See if want to use 5 year skip option
  acceptable=0
  while [[ $acceptable = 0 ]]
  do
    print -n "Do you want the 5 year printing option (y/n)? <y> "
    read YAORNA
    case $YAORNA in
         [Yy]    ) Y5OPTION=1
                 SKIPYR=2020
                 acceptable=1;;
         [Nn]    ) Y5OPTION=0
                 SKIPYR=2050
                 acceptable=1;;         
         *       ) if [[ -z "$YAORNA" ]]; then
                   Y5OPTION=1
                   SKIPYR=2020
                   acceptable=1
                 else  
                   print " *** UNACCEPTABLE RESPONSE - RE-ENTER ***"     
                 fi;;
    esac     
  done
  # --- If 5 year skip option selected, determine first skip year
  if [[ "$Y5OPTION" = 1 ]]; then
    acceptable=0
    while [[ $acceptable = 0 ]]
    do
      print -n "Enter the year to start skipping: <$SKIPYR> "
      read SKIPYR
      if [[ "$SKIPYR" < $FYR || "$SKIPYR" > $LYR ]]; then
        if [[ -z "$SKIPYR" ]]; then
          SKIPYR=2020
          acceptable=1
        else
          print " *** UNACCEPTABLE RESPONSE - RE-ENTER ***"
          print " "
        fi
      else
        acceptable=1  
      fi
    done
  fi
  # --- See if want growth column in the report
  acceptable=0
  while [[ $acceptable = 0 ]]
  do
    YAORNA=""
    print -n "Do you want to have the growth column (y/n)? <y>"
    read YAORNA
    if [[ -z "$YAORNA" ]]; then
          YAORNA="y"
    fi
    case $YAORNA in
       [Yy]    ) GROWCOL="y";;
       *       ) GROWCOL="n";;
    esac     
    case $GROWCOL in
         [Yy]    ) DOGROW=1
                   C_reply=""
                   print -n "In calendar years, which year would you like as a base year for calculating the growth rate? <$default_year> "
                   read C_reply
                      if [[ -z "$C_reply" ]]; then
                          GROWYR="$default_year"
                      else
                          GROWYR="$C_reply"
                      fi
                 acceptable=1;;
         [Nn]    ) DOGROW=0
                   GROWYR="$default_year"
                 acceptable=1;;         
         *       ) if [[ -z "$GROWCOL" ]]; then
                   DOGROW=1
                   acceptable=1
                 else  
                   print " *** UNACCEPTABLE RESPONSE - RE-ENTER ***"
                 fi;;
    esac
  done
  # --- Set year to start growth rate
C_reply=""
print -n "In calendar years, which year would you like the cumulative capacity additions to begin? <$default_year> "
read C_reply
  if [[ -z "$C_reply" ]]; then
      CUMCAPADD="$default_year"
  else
      CUMCAPADD="$C_reply"
  fi
C_reply=""
print -n "In calendar years, which year would you like the cumulative oil and gas production to begin? <$default_year> "
read C_reply
  if [[ -z "$C_reply" ]]; then
      CUMOILGAS="$default_year"
  else
      CUMOILGAS="$C_reply"
  fi
  # --- Set dollar year
  acceptable=0
  while [[ $acceptable = 0 ]]  
  do
    print -n "Enter dollar year (deflator) to use (1987-2050). <$DEFDOLYR> "
    read DOLARYR
    if [[ "$DOLARYR" > 1986 && "$DOLARYR" < 2051 ]]; then
      acceptable=1
    else 
      if [[ -z "$DOLARYR" ]]; then   
        DOLARYR=$DEFDOLYR
        acceptable=1
      else  
        print " *** UNACCEPTABLE RESPONSE - RE-ENTER ***"     
      fi
    fi
  done      
else
  # --- Default print options set, if they were selected
  REGIONS=0
  FYR=2002
  LYR=2030
  Y5OPTION=0
  SKIPYR=2020
  DOGROW=0
  GROWYR="$default_year"
  DOLARYR="$default_year"
  CUMCAPADD="$default_year"
  CUMOILGAS="$default_year"
  FTABCARB="co2"
fi
# --- See if user wishes to generate a worksheet of the report.
print " "
print -n "Do you want to create a worksheet (y/n)? <n>"
read YAORNA
case "$YAORNA" in
   [Yy]    ) DOWK1=1;;
   *       ) DOWK1=0;;         
esac 
# --- See if user wishes to generate a graf2000 file
print " "
print -n "Do you want to create a file for graf2000 (y/n)? <n>"
read YAORNA
case "$YAORNA" in
   [Yy]    ) LADYFILE=4;;
   *       ) LADYFILE=0;;         
esac 
if [ "$NUMSCEN" = 1 ]; then
  date > temp.$$ ; read VAR1 < temp.$$ ; rm temp.$$
  COMMENT=" in $RUNDIR reported on $VAR1"
else
  COMMENT=" (1),"
  let count=2
  while [[ $count < $NUMSCEN ]]
  do
    print "$COMMENT ${SCEN[$count]}.${DATEKEY[$count]} ($count), " > temp.$$
    read COMMENT < temp.$$ ; rm temp.$$
    let count=count+1
  done
  print "$COMMENT and ${SCEN[$count]}.${DATEKEY[$count]} ($count). " > temp.$$
  read COMMENT < temp.$$ ; rm temp.$$
fi  
if [ $DOLARYR != $DEFDOLYR ]; then
  print "$COMMENT. Dollar year is $DOLARYR." > temp.$$ ; read COMMENT < temp.$$ ; rm temp.$$
fi   
print "Please enter a comment for the report:"
print "< ${SCEN[1]}.${DATEKEY[1]} $COMMENT >"
read COMMENT2
if [[ -n "$COMMENT2" ]]; then
  COMMENT=$COMMENT2
fi  
# See which version of code user wants
acceptable=0
  while [[ $acceptable = 0 ]]
  do
    print " "
    print "Select report writer to use:"
    print "     1 - AEO 2000" 
    print "     2 - AEO 2001" 
    print "     3 - McIntosh I compatible"
    print "     4 - McIntosh II (Mercury mission) compatible"
    print "     5 - Jefferman/3 Republican compatible (current)"
    print "     6 - AEO 2002"
    print "     7 - AEO 2003"
    print "     8 - McCain/Lieberman compatible"
    print "     9 - AEO 2004"
    print "    10 - AEO 2005"
    print "    11 - Current default"
    print -n "Enter your choice (1-11) :<11>"
    read SELECTED

    case "$SELECTED" in
      1        ) reptype=aeo2k
                 echo "Setting print dollar year to 1998"
                 DEFDOLYR=1998
                 CUMCAPADD=1998
                 CUMOILGAS=1998
                 FTABCARB="c"
                 LYR=2020
                 acceptable=1 ;;
      2        ) reptype=aeo2001
                 echo "Setting print dollar year to 1999"
                 DEFDOLYR=1999
                 CUMCAPADD=1999
                 CUMOILGAS=1999
                 FTABCARB="c"
                 LYR=2020
                 acceptable=1 ;;
      3        ) reptype=mcintosh
                 DEFDOLYR=1999
                 CUMCAPADD=1999
                 CUMOILGAS=1999
                 FTABCARB="c"
                 LYR=2020
                 acceptable=1 ;;
      4        ) reptype=mercury
                 DEFDOLYR=1999
                 CUMCAPADD=1999
                 CUMOILGAS=1999
                 FTABCARB="c"
                 LYR=2020
                 acceptable=1 ;;
      5        ) reptype=jefferep
                 DEFDOLYR=1999
                 CUMCAPADD=1999
                 CUMOILGAS=1999
                 FTABCARB="c"
                 LYR=2020
                 acceptable=1 ;;
      6        ) reptype=aeo2002
                 echo "Setting print dollar year to 2000"
                 DEFDOLYR=2000
                 CUMCAPADD=2000
                 CUMOILGAS=2000
                 FTABCARB="c"
                 LYR=2020
                 acceptable=1 ;;
      7        ) reptype=aeo2003
                 echo "Setting print dollar year to 2001"
                 DEFDOLYR=2001
                 CUMCAPADD=2001
                 CUMOILGAS=2001
                 FTABCARB="c"
                 LYR=2025
                 acceptable=1 ;;
      8        ) reptype=mccainlieb
                 DEFDOLYR=2001
                 CUMCAPADD=2001
                 CUMOILGAS=2001
                 FTABCARB="c"
                 LYR=2025
                 acceptable=1 ;;
      9        ) reptype=aeo2004
                 echo "Setting print dollar year to 2002"
                 DEFDOLYR=2002
                 CUMCAPADD=2002
                 CUMOILGAS=2002
                 LYR=2025
                 lnkinems=0
                 acceptable=1 ;;
     10        ) reptype=aeo2005
                 echo "Setting print dollar year to 2003"
                 DEFDOLYR=2003
                 CUMCAPADD=2003
                 CUMOILGAS=2003
                 LYR=2025
                 lnkinems=0
                 acceptable=1 ;;
     11        ) reptype=default
                 lnkinems=1
                 acceptable=1 ;;
      *        )  if [[ -z "$SELECTED" ]]; then
                    reptype=default
                    lnkinems=1
                    acceptable=1 
                  else
                    print "*** UNACCEPTABLE RESPONSE - RE-ENTER ***"
                  fi;;
    esac
  done
# --- Get default version of dictionary
grep "dict.txt input $reptype" $NEMS/logs/DEFAULTS > temp.$$
read junk1 junk2 junk3 dictvers junkend < temp.$$ ; rm temp.$$
DICT="$NEMS/input/dict.v$dictvers.txt"
if [ $reptype = "mcintosh" ] ; then
  DICT="M:/rec/rsc/merc/input/dict.mc.txt"
  echo "Setting print dollar year to 2001"
  DEFDOLYR=2001
  FTABCARB="c"
fi
if [ $reptype = "mercury" ] ; then
  DICT="M:/rec/rsc/merc/input/dict.mc.txt"
  echo "Setting print dollar year to 2001"
  DEFDOLYR=2001
  FTABCARB="c"
fi
if [ $reptype = "jefferep" ] ; then
  DICT="M:/rec/rsc/merc/input/dict.nox.txt"
  echo "Setting print dollar year to 2001"
  DEFDOLYR=2001
  FTABCARB="c"
fi
if [ $reptype = "mccainlieb" ] ; then
  DICT="N:/default/input/dict.v1.66.txt"
  echo "Setting print dollar year to 2001"
  DEFDOLYR=2001
  FTABCARB="c"
fi
sh -K $NEMS/scripts/checkfor.z.sh $DICT print
# --- LAYOUT portion of script
# --- Find out if want to use default or user layout file
self=0
acceptable=0
case "$reptype" in
 mcintosh ) LAYOUT="M:/rec/rsc/merc/input/layout.mc.txt" ;;
 mercury  ) LAYOUT="M:/rec/rsc/merc/input/layout.mc.txt" ;;
 jefferep ) LAYOUT="M:/rec/rsc/merc/input/layout.nox.txt" ;;
 mccainlieb ) LAYOUT="L:/main/pkc/jq5/publish/layout.txt" ;;
 *        )
while [[ $acceptable = 0 ]]
do
  print " "
  print -n "Do you want to use the $reptype layout file (y/n) <y>?"
  read SELLAYOT

  case $SELLAYOT in
      [Yy]        ) grep "layout.txt input $reptype" $NEMS/logs/DEFAULTS > temp.$$
                    read junk1 junk2 junk3 layvers junkend < temp.$$ ; rm temp.$$
                    LAYOUT="$NEMS/input/layout.v$layvers.txt"
                    sh -K $NEMS/scripts/checkfor.z.sh $LAYOUT print
                    acceptable=1 ;;
      [Nn]        ) acceptable=1 ; self=1;;
      *        )  if [[ -z "$SELLAYOT" ]]; then
# --- Set layout file -- need to something similiar to above later
                    grep "layout.txt input $reptype" $NEMS/logs/DEFAULTS > temp.$$
                    read junk1 junk2 junk3 layvers junkend < temp.$$ ; rm temp.$$
                    LAYOUT="$NEMS/input/layout.v$layvers.txt"
                    sh -K $NEMS/scripts/checkfor.z.sh $LAYOUT print
                    acceptable=1 
                  else
                    print "*** UNACCEPTABLE RESPONSE - RE-ENTER ***"
                  fi;;
  esac
done  
#
# --- get a valid name for layout file if answer was No to $reptype version
while [[ $self = 1 ]]
do
  print -n 'Enter the name of the layout file: '
  read LAYOUT
# --- check existence, access, and file type of layout file
  sh -K $NEMS/scripts/checkfor.z.sh $LAYOUT
  if read_access $LAYOUT; then
    self=0
  else
    print "$0: *** ENTER LAYOUT FILE AGAIN ***"
    print " "
    print " "
  fi
done
;;
esac

# --- Get STIFDATA file 
sh -K $NEMS/scripts/fdef.sh stifdata.txt s | sed "s/.*is //g" > temp.$$ ; read stifvers < temp.$$ ; rm temp.$$
STIFDATA=$NEMS/input/stifdata.v$stifvers.txt

# --- Get footnote source file 
sh -K $NEMS/scripts/fdef.sh citation.txt s | sed "s/.*is //g" > temp.$$ ; read citevers < temp.$$ ; rm temp.$$
CITATION=$NEMS/input/citation.v$citevers.txt
if [ -f citation.txt ] ; then
  CITATION=citation.txt
  echo "Local footnote source citation file found, so it will be used."
fi

# --- create file ftab.sed
print "s!SCENARIO!${SCEN[1]}!" > ftab.sed
print "s!DATEKEY!${DATEKEY[1]}!" >> ftab.sed
print "s!REPCOMMENT!$COMMENT!" >> ftab.sed
print "s!REGIONS!$REGIONS!" >> ftab.sed
print "s!FYR!$FYR!" >> ftab.sed
print "s!LYR!$LYR!" >> ftab.sed
print "s!DOGROW!$DOGROW!" >> ftab.sed
print "s!GROWYR!$GROWYR!" >> ftab.sed
print "s!Y5OPTION!$Y5OPTION!" >> ftab.sed
print "s!SKIPYR!$SKIPYR!" >> ftab.sed
print "s!NUMSCEN!$NUMSCEN!" >> ftab.sed
print "s!DOLARYR!$DOLARYR!" >> ftab.sed
print "s!DOWK1!$DOWK1!" >> ftab.sed
print "s!TABREQ!$TABREQ!" >> ftab.sed
print "s!DICT!$DICT!" >> ftab.sed
print "s!LAYOUT!$LAYOUT!" >> ftab.sed
print "s!FTABCARB!$FTABCARB!" >> ftab.sed
let count=0
while [[ $count < $NUMSCEN ]]
do
  let count=count+1  
  print "s!RESTART$count!${RESTART[$count]}!" >> ftab.sed
done  
print "s!STIFDATA!$STIFDATA!" >> ftab.sed
case "$SELECTED" in
  1        ) print "s!CITATION!0!" >> ftab.sed
             ;;
  *        ) print "s!CITATION!$CITATION!" >> ftab.sed
             ;;
esac
print "s!LADYFILE!$LADYFILE!" >> ftab.sed
print "s!CUMCAPADD!$CUMCAPADD!" >> ftab.sed
print "s!CUMOILGAS!$CUMOILGAS!" >> ftab.sed
# --- Use ftab.sed and ftab.template to create ftab.dat
TEMPLATE="$NEMS/scripts/ftab.template"
sed -f ftab.sed $TEMPLATE > ftab.dat
# --- Delete ftab.sed, since it is no longer needed
rm ftab.sed
# --- Get object file defaults, used to create ftab executable
case "$reptype" in
 mcintosh )
  ftabname="M:/rec/rsc/merc/src/ftab.mc.obj"
  ftab2name="M:/rec/rsc/merc/src/ftab2.obj"
  filername="M:/rec/rsc/merc/src/filer.mc.obj"
  ;;
 mercury )
  ftabname="M:/rec/rsc/merc/src/ftab.mc.obj"
  ftab2name="M:/rec/rsc/merc/src/ftab2.obj"
  filername="M:/rec/rsc/merc/src/filer.mc.obj"
  ;;
 jefferep )
  ftabname="M:/rec/rsc/merc/src/nox/ftab.nox.obj"
  ftab2name="M:/rec/rsc/merc/src/nox/ftab2.obj"
  filername="M:/rec/rsc/merc/src/nox/filer.mc.obj"
  ;;
 mccainlieb )
  ftabname="L:/main/pkc/jq5/publish/ftab.obj"
  ftab2name="L:/main/pkc/jq5/publish/ftab2.obj"
  filername="N:/default/objects/filer.v1.88.obj"
  ;;
 * )
  grep "ftab.obj objects $reptype" $NEMS/logs/DEFAULTS > temp.$$
    read junk1 junk2 junk3 vers1 junkend < temp.$$ ; rm temp.$$
  grep "ftab2.obj objects $reptype" $NEMS/logs/DEFAULTS > temp.$$
    read junk1 junk2 junk3 vers2 junkend < temp.$$ ; rm temp.$$
  grep "filer.obj objects $reptype" $NEMS/logs/DEFAULTS > temp.$$
    read junk1 junk2 junk3 vers3 junkend < temp.$$ ; rm temp.$$
ftabname="$NEMS/objects/ftab.v$vers1.obj"
if [ -f ftab.obj ] ; then
  ftabname="ftab.obj"
  echo "Local ftab.obj found, so it will be used."
fi
ftab2name="$NEMS/objects/ftab2.v$vers2.obj"
if [ -f ftab2.obj ] ; then
  ftab2name="ftab2.obj"
  echo "Local ftab2.obj found, so it will be used."
fi
filername="$NEMS/objects/filer.v$vers3.obj"
if [ -f filer.obj ] ; then
  filername="filer.obj"
  echo "Local filer.obj found, so it will be used."
fi
;;
esac
grep "fwk1io.obj objects default" $NEMS/logs/DEFAULTS > temp.$$
  read junk1 junk2 junk3 vers4 junkend < temp.$$ ; rm temp.$$
grep "cio4wk1.obj objects default" $NEMS/logs/DEFAULTS > temp.$$
  read junk1 junk2 junk3 vers5 junkend < temp.$$ ; rm temp.$$
if [[ $lnkinems = 1 ]] ; then
  echo "Intel linker will be used."
  fwk1name="$NEMS/objects/fwk1io.v$vers4.obj"
  cioname="$NEMS/objects/cio4wk1.v$vers5.obj"
else
  echo "CVF linker will be used."
  fwk1name="$NEMS/objects/fwk1io.v1.4.obj"
  cioname="$NEMS/objects/cio4wk1.v1.3.obj"
fi
#
# --- Link FTAB   
echo $ftabname $ftab2name $filername
print "Please wait, ftab executable is being created."
OBJSFTAB="\
$ftabname \
$ftab2name \
$filername \
$fwk1name \
$cioname "

 notthere=0
 for item in $OBJSFTAB
 do
    sh -K $NEMS/scripts/checkfor.z.sh $item print
    if [ $? -ne "0" ] ; then
      notthere=1
    fi
 done
 if [ $notthere -eq 1 ] ;then
   echo "not continuing because of missing object files"
   exit
 fi
echo $OBJSFTAB | sed 's/\//\\/g' > ftab.objs
# set the directory for link files to the current directory
TMP="$PWD"
export TMP
if [[ $lnkinems = 0 ]] ; then
  link /out:ftab.exe /warn:0 /debug:full /FORCE @ftab.objs
else
  . $NEMS/scripts/ifortvars.sh
  xilink /out:ftab.exe /debug:full /FORCE @ftab.objs
fi
# --- See if wish to run FTAB now
acceptable=0
while [[ $acceptable = 0 ]]
do
  print " "
  print -n "DO you want to run FTAB now (y/n)? "
  read RUNITNOW
  case $RUNITNOW in
       [Yy]    ) self=0
                 acceptable=1;;
       [Nn]    ) self=1
                 acceptable=1;;         
       *       ) if [[ -z "$RUNITNOW" ]]; then
                   print " *** THIS ITEM HAS NO DEFAULT "
                 fi  
                 print " *** UNACCEPTABLE RESPONSE - RE-ENTER ***";;
  esac     
done
logstr="echo nftab $USER `date`"
$logstr >> $NEMS/logs/ftablog
if [[ $self = 0 ]]; then
   ftab  < ftab.dat 
else
   print " "
   print " "
   print "ENTER THE FOLLOWING FROM CURRENT DIRECTORY, WHEN YOU ARE READY TO RUN FTAB:"
   print " "
   print "   ftab < ftab.dat "   
   print " "
   print " "
fi
