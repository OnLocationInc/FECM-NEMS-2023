#$Header: N:/default/scripts/RCS/readda.sh,v 1.5 2005/10/12 20:23:11 DSA Exp $
# READDA script
# create an input file called readda.options that looks something like this:

#   Scenario
#   Datekey
#   Sector   two char code:RS,CM,IN,TR,EL or AS
#   0 REG 0 
#   0 REG 1
#   UNDERSCORE
#   % CHANGE
# make sure they're not in the directory for this script when they execute it.
 if [ $PWD = "$NEMS/scripts" ]
   then
   echo "     Sorry.  There is a slight problem."
   echo "     Your current directory is  $PWD."
   echo "     Please execute this from another directory."
   exit 1
 fi
 print " "
 print "                        ******************               "
 print "                        *    READDA      *               "          
 print "                        ******************               "
 print " "
 rem="y"
 if [ -a readda.options ] ; then 
   head -1 readda.options > temp.$$ ; read SCEN < temp.$$ ; rm temp.$$
   head -2 readda.options | tail -1 > temp.$$ ; read DATE < temp.$$ ; rm temp.$$
   echo "The readda setup file, readda.options for $SCEN.$DATE exists.  "
   read rem?"Remove it and create new one (y/n)? [n] : "
   if [ -z "$rem" ] ; then
     rem="n"
   fi
 fi
 case $rem in
     y|Y|yes|YES) 
     if [ -a readda.options ] ; then
        rm readda.options 
     fi

# initialize number of shell files and their names
   numshell=1
   shellfile[1]="$NEMS/scripts/readda.shell"
   actualfile[1]="readda.options"

# set default for scenario
 SCEN="aeo2kr"
# set default for output sectors
 SECTOR="AS"
# set default for output regions
 REGIONS=ALL
# set default for start year
 STARTYR="1998"
# set default for last year
 LASTYR="2020" 
# set default for underscore
 UNDER="NO"
# set default for % change
 TOLER="5"
  
#=========================================================================================
 numarg=$#
# check for argument string   
# arg 1:  scenario
# arg 2:  datekey
# arg 3:  output directory path
 if [ $numarg -gt 0 ]; then
   SCEN=$1
   shift
   numarg=$#
 else
   echo " "
   read scen?" Enter NEMS Scenario [$SCEN]: "
   if [ -n "$scen" ]; then 
     SCEN=$scen
   fi
 fi
 if [ $numarg -gt 0 ]; then
   DATE=$1
   shift
   numarg=$#
 else
  read date?" Enter NEMS Datekey: "
  DATE=$date

 fi

# grep the scenario and datekey from user
        
    grep  \/$SCEN\/$DATE $NEMS/logs/runlog | sed "s!... /!/!" > temp.$$ ; read RUNPATH < temp.$$ ; rm temp.$$
    MNPQIT="$RUNPATH/MNPQIT.daf"
    echo "MNPQIT FILE: $MNPQIT"
    if [ ! -r $MNPQIT ] ; then
      echo "MNPQIT file not found"
      exit
    else
      echo "$MNPQIT exists" 
    fi

 echo " "
 echo " Select sector to include:"
 echo "    RS - Residential"
 echo "    CM - Commercial"
 echo "    IN - Industrial"
 echo "    TR - Transportation"
 echo "    EL - Electricity"
 echo "    AS - All sectors"
 read sector?" Enter 2-character code:[$SECTOR] "
 sector=$(print $sector | tr '[a-z]' '[A-Z]')
 if [ -n "$sector" ];then
    SECTOR=$sector
 fi

 choice="0"
 while [[ $choice -ne 1 && $choice -ne 2 ]]
 do
   echo " " 
   echo " Enter Output Regions: "
   echo
   echo " 1> All Regions"
   echo " 2> One Region"
   echo " "
   read choice?" Enter selected option : "
 done
 if [[ $choice -eq 1 ]];then
   REGIONS=ALL
 elif [[ $choice -eq 2 ]];then
   pickedreg="0"
   while [[ $pickedreg -lt 1 || $pickedreg -gt 23 ]]
   do
     read pickedreg?" Enter a region [1 - 23]: "
   done
   case $pickedreg in
     10) REGIONS="0" ;;
     11) REGIONS="A" ;;
     12) REGIONS="B" ;;
     13) REGIONS="C" ;;
     14) REGIONS="D" ;;
     15) REGIONS="E" ;; 
     16) REGIONS="F" ;;
     17) REGIONS="G" ;; 
     18) REGIONS="H" ;;
     19) REGIONS="I" ;;
     20) REGIONS="J" ;;
     21) REGIONS="K" ;;
     22) REGIONS="L" ;;
     23) REGIONS="M" ;;
     *)  REGIONS=$pickedreg ;; 
   esac   
 fi
 
 print 
 read startyr?" Enter Start Year? [$STARTYR] "
  if [ -n "$startyr" ];then
    STARTYR=$startyr
  fi

 print
 read lastyr?" Enter Last Year? [$LASTYR] "
  if [ -n "$lastyr" ];then
    LASTYR=$lastyr
  fi
 
 print
 read under?" Do you want to underscore? [$UNDER] "
  if [ -n "$under" ];then
    UNDER=$under
  fi

 print
 read toler?" Enter % change: [$TOLER] " 
 if [ -n "$toler" ];then
   TOLER=$toler
 fi
#===================================================================================
#     copy  shell files.

  n=1
    
    cp ${shellfile[((n))]} ${actualfile[((n))]}
    chmod ugo+w ${actualfile[((n))]} 

#===================================================================================

#  3) Invoke awk scripts to create string substitutions to
#     be processed by the sed stream editor.


#     Set output directory as first sed substitue command 
       echo "s/\?SCEN@/$SCEN/g"                    > keys.sed
       echo "s/\?DATE@/$DATE/g"                    >> keys.sed
       echo "s/\?SECTOR@/$SECTOR/g"                >> keys.sed
       if [[ $REGIONS = ALL ]];then
         echo "s/0 REG/1 REG/g"                    >> keys.sed
       else
         echo "s/0 REG $REGIONS/1 REG $REGIONS/"   >> keys.sed 
       fi
       echo "s/\?STARTYR@/$STARTYR/g"              >> keys.sed
       echo "s/\?LASTYR@/$LASTYR/g"                >> keys.sed
       echo "s*\?RUNPATH@*$RUNPATH*g"              >> keys.sed
       echo "s/\?UNDER@/$UNDER/g"                  >> keys.sed
       echo "s/\?TOLER@/$TOLER/g"                  >> keys.sed


#     Apply string substitutions to the shell files to create the actual files
       n=1
       while [ "$n" -le "$numshell" ] 
       do
         sed -f keys.sed ${actualfile[((n))]} > tempfile
         cp tempfile ${actualfile[((n))]}
         n=`expr $n + 1 `
       done 


#    4) Clean up temporary files

       rm keys.sed
       rm tempfile 
;;
esac
#=================================================================================
#    5) Linke readda  
if [ -r "readda.obj" ] ; then
  echo "local readda.obj found so it will be used"
  OBJS="readda.obj"
else
  sh -K $NEMS/scripts/fdef.sh readda.obj s | sed 's/.* is //' > temp.$$ ; read vers < temp.$$ ; rm temp.$$
  OBJS="$NEMS/objects/readda.v$vers.obj"
fi
 notthere=0
 for item in $OBJS
 do
    sh -K $NEMS/scripts/checkfor.z.sh $item print
    if [ $? -ne "0" ] ; then
      notthere=1
    fi
 done
 if [ $notthere -eq 1 ] ;then
   echo "not continuing because of missing object files"
   exit
 fi

echo $OBJS | sed 's@\/@\\@g' > readda.objs
# set the directory for link files to the current directory
TMP="$PWD"
export TMP
. $NEMS/scripts/ifortvars.sh
xilink /out:readda.exe /FORCE @readda.objs
#    6) run readda to create an output file
 echo "running readda.e using the following command:"
 echo "readda.exe < readda.options > readda.output.$SCEN.$DATE"
 read ans?"Hit ENTER to continue"
       readda.exe < readda.options > readda.output.$SCEN.$DATE
