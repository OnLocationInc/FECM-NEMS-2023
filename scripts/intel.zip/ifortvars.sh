# Sets the environment strings for Intel Fortran and ".net" (linker and libraries).
#  This is based on two bat files that implement the Intel Fortan command line environment,
#  vsvars32.bat and ifortvars.sh
#
# 1) set environment as done in vsvars32.bat, translated to kornshell syntax
export VSINSTALLDIR='C:\Program Files\Microsoft Visual Studio .NET 2003\Common7\IDE'
export VCINSTALLDIR='C:\Program Files\Microsoft Visual Studio .NET 2003'
export FrameworkDir='C:\WINDOWS\Microsoft.NET\Framework'
export FrameworkVersion='v1.1.4322'
export FrameworkSDKDir='C:\Program Files\Microsoft Visual Studio .NET 2003\SDK\v1.1'
export DevEnvDir=$VSINSTALLDIR
export MSVCDir=$VCINSTALLDIR'\VC7'
export PATH=$DevEnvDir';'$MSVCDir'\BIN;'$VCINSTALLDIR'\Common7\Tools;'$VCINSTALLDIR'\Common7\Tools\bin\prerelease;'$VCINSTALLDIR'\Common7\Tools\bin;'$FrameworkSDKDir'\bin;'$FrameworkDir'\'$FrameworkVersion';'$PATH';'
export LIB=$MSVCDir'\ATLMFC\LIB;'$MSVCDir'\LIB;'$MSVCDir'\PlatformSDK\lib\prerelease;'$MSVCDir'\PlatformSDK\lib;'$FrameworkSDKDir'\lib;'$LIB
export INCLUDE=$MSVCDir'\ATLMFC\INCLUDE;'$MSVCDir'\INCLUDE;'$MSVCDir'\PlatformSDK\include\prerelease;'$MSVCDir'\PlatformSDK\include;'$FrameworkSDKDir'\include;'$INCLUDE

# 2) set envirnoment as done in ifortvars.bat

#echo 'Intel(R) Visual Fortran Compiler 9.0.020 Build Environment for 32-bit applications'
#echo 'Copyright (C) 1985-2005 Intel Corporation. All rights reserved.'

export IFORT_COMPILER90='C:\Program Files\Intel\Compiler\Fortran\9.0'
export INTEL_SHARED='C:\Program Files\Common Files\Intel\Shared Files'
export INTEL_LICENSE_FILE='C:\Program Files\Common Files\Intel\Licenses'
export PATH=$IFORT_COMPILER90'\Ia32\Bin;'$INTEL_SHARED'\Ia32\Bin;'$PATH
export LIB=$IFORT_COMPILER90'\Ia32\Lib;'$LIB
export INCLUDE=$IFORT_COMPILER90'\Ia32\Include;'$INCLUDE


